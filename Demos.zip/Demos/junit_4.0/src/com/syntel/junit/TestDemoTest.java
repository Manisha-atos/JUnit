package com.syntel.junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class TestDemoTest {

private static TestDemo t;	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	t=new TestDemo();
	System.out.println("In setUpBefore class.....");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		t=null;
		System.out.println("In tearDownAfter class.....");
		
	}

	@Before
	public void setUp() throws Exception {
	System.out.println("In setup............");
	}

	@After
	public void tearDown() throws Exception {
	System.out.println("In teardown.....");
	}

	@Test(expected=RuntimeException.class)
	public void testAcceptAge() {
	assertEquals(true, t.acceptAge(25));
	}

	@Test
	public void testAcceptMobile() {
		fail("Not yet implemented");
	}


	@Ignore
	@Test
	public void x() {
		fail("Not yet implemented");
	}


}
