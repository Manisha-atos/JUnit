package com.syntel.junit;

import java.util.Arrays;
import java.util.Collection;
import static org.junit.Assert.*;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
public class ParameterizedTest {
       private int input;
	   private boolean output;
	   private static TestDemo t;
	   
	   
	  	   
	   public ParameterizedTest(int input, boolean output) {
		this.input = input;
		this.output = output;
	System.out.println("Param constructor  input :"+input+" ,output :"+output);
	   }

	@BeforeClass
		public static void setUpBeforeClass() throws Exception {
		t=new TestDemo();
		System.out.println("In setUpBefore class.....");
		}

		@AfterClass
		public static void tearDownAfterClass() throws Exception {
			t=null;
			System.out.println("In tearDownAfter class.....");
			
		}

		@Parameterized.Parameters
		   public static Collection inputAges() {
		      return Arrays.asList(new Object[][] {
		         { 20, true },
		         { 6, false },
		         { 25, true },
		         { 61, false },
		         { 60, true }
		      });
		   }

		// This test will run 4 times since we have 5 parameters defined
		   @Test
		   public void testAcceptAge() {
		      System.out.println("Parameterized Number is : " + input);
		      assertEquals(output,t.acceptAge(input));
		   }
	
}
