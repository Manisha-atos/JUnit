package com.syntel.junit;

public class TestDemo {

	public boolean acceptAge(int age){

		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return age>=20 && age<=60;
	}
	

	public boolean acceptMobile(String mobile){
		return mobile.matches("[1-9][0-9]{9,9}");
	}
	
}
