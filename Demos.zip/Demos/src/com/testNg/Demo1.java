package com.testNg;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Demo1 
{
	MathService ser;
	@BeforeClass
	public void beforeClass()
	{
	ser=new MathService();
	}
	@Test
	public void chekAdd()
	{		
		assertEquals(ser.add(2, 3),5);		
	}
	@Test
	public void chekSub()
	{
		assertEquals(ser.sub(8, 3),15);
		
	}
	
	

}
