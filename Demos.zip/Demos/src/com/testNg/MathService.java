package com.testNg;

public class MathService implements mathInterface {

	@Override
	public int add(int x, int y) {
		// TODO Auto-generated method stub
		return x+y;
		
	}

	@Override
	public int sub(int x, int y) {
		// TODO Auto-generated method stub
		return x-y;
		
	}
}
