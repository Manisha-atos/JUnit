package com.testNg;
public interface mathInterface {
public int add(int x,int y);
public int sub(int x,int y);
}
