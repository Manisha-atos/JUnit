package com.p3;

import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestSuiteSetup {
	public static WebDriver driver;
	@BeforeSuite
	public void setupSuite() {
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@AfterSuite
	public void tearDown() {
	driver.close();
	}
	@BeforeClass
	void setBrowser()
	{
		
		//driver.get("http://www.google.com");
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.manage().window().setSize(new Dimension(1920, 1080));
	}
	@BeforeTest
	void testMethod()
	{
		driver.get("file:///D:/SeleniumCEP/DemoHTML/Home.html");
		
	}
	@BeforeMethod
	void home()
	{
		driver.get("file:///D:/SeleniumCEP/DemoHTML/Home.html");
	}
	@Test(priority=1)
	void loginTest()
	{
		WebElement l=driver.findElement(By.partialLinkText("Log"));
		l.click();
		driver.findElement(By.name("uname")).sendKeys("Manisha");
		driver.findElement(By.name("pwd")).sendKeys("Syntel123$");
		driver.findElement(By.name("btnSbt")).click();
	}

	
	@AfterTest
	void logOut()
	{
		System.out.println("logout");
	}
	

}
