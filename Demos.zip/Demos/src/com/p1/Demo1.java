package com.p1;
import static org.testng.Assert.assertEquals;

import org.testng.annotations.*;
public class Demo1 {
//	@BeforeSuite
//	void bSuit()
//	{
//		System.out.println("before suit");
//	}
//	@AfterSuite
//	void aSuit()
//	{
//		System.out.println("after suit");
//	}
	@BeforeTest
	void bTest()
	{
		System.out.println("before test");
	}
	@AfterTest
	void aTest()
	{
		System.out.println("after test");
	}
	@BeforeMethod
	void init()
	{
		System.out.println("before method");
	}
	@Test
	void login()
	{
		System.out.println("hello");
	}
	@Test
	void logout()
	{
		System.out.println("logout");
	}
	@AfterMethod
	void des()
	{
		System.out.println("after des");
	}
}
