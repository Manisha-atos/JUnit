package com.p1;
import static org.testng.Assert.assertEquals;

import org.testng.annotations.*;
//set priority
public class Demo3 {
	
/*@Test(priority=1)
public void testLogin()
{	
	System.out.println("test Login...");
}
@Test(priority=2 )
public void testChkMail()
{
System.out.println("checkting mail");
}
//@Test(enabled=false)
@Test
public void testDelmail()
{
System.out.println("deleting mail");
}

@Test(priority=3)
public void testSendMail()
{
System.out.println("sending mail");
}
*/
String ver;
@BeforeClass
void init()
{
	ver="RLT";
	System.out.println("init");
}	

@Test
void testMethod2()
{
System.out.println("all ");
}
@Test
void testMethod1()
{
System.out.println("hello");
}
@AfterClass
void destroy()
{
ver=null;
System.out.println("destroy");
}

}
