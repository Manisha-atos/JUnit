package com.p1;
import org.testng.Assert;
import org.testng.annotations.Test;
public class Demo4 {
//Grouping in testng
	@Test
	  public void test_login() {
		  System.out.println("login tested");
		  Assert.fail();
	  }
	@Test(priority=2,dependsOnMethods={"test_login"})
	public void test_compose(){
  		System.out.println("Compose tested");
  	}
	@Test(priority=1,dependsOnMethods={"test_login","test_compose"})
	public void test_inbox1(){
  		System.out.println("inbox tested");
  }
	
	@Test(priority=1,dependsOnMethods={"test_login"})
	public void test_inbox(){
  		System.out.println("inbox tested");
  	}
}
