package com.p1;
import static org.testng.Assert.assertEquals;

import org.testng.annotations.*;

public class Demo2 {
	@Test
	void testMethod1()
	{
		System.out.println("meth1");
	}
	
@Test
public void Login()
{	
	System.out.println("Login...Demo2");
}

String ver;
@BeforeClass
void init()
{
	ver="RLT";
	System.out.println("init");
}	

@Test
void testMethod2()
{
System.out.println("all ");
}

@AfterClass
void destroy()
{
ver=null;
System.out.println("destroy");
}

}
