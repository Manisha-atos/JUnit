package com.p2;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
public class Demo2 {
@BeforeSuite
void bSuit()
{
	System.out.println("before suit");
}
@AfterSuite
void aSuit()
{
	System.out.println("after suit");
}
@BeforeTest
void bTest()
{
	System.out.println("before test");
}
@AfterTest
void aTest()
{
	System.out.println("after test");
}
@BeforeMethod
void init()
{
	System.out.println("before method");
}
@Test
void login()
{
	System.out.println("hello");
}
@Test
void logout()
{
	System.out.println("logout");
}
@AfterMethod
void des()
{
	System.out.println("after des");
}
}
