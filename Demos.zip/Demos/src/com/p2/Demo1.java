package com.p2;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


public class Demo1 {
	
	String ver;
	@BeforeClass
	void init()
	{
		ver="RLT";
		System.out.println("init");
	}	
	
@Test
void testMethod2()
{
	System.out.println("all ");
}
@Test
void testMethod1()
{
	System.out.println("hello");
}
@AfterClass
void destroy()
{
	ver=null;
	System.out.println("destroy");
}
}
