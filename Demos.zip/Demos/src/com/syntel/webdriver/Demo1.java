package com.syntel.webdriver;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
public class Demo1 {
	
		
	
		
	//FirefoxDriver driver =new FirefoxDriver();
// driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);	    
//	driver.manage().window().maximize();
//	driver.get("http://www.google.com/");
//	System.out.println("current URL: "+driver.getCurrentUrl());
//	driver.navigate().to("https://webapp2.syntelinc.com/owa");
//	String URL = driver.getCurrentUrl();
//	System.out.println("URL Is: "+ URL);
//	driver.navigate().back();
//	System.out.println("current URL: "+driver.getCurrentUrl());
//	driver.navigate().forward();
//	System.out.println("current URL: "+driver.getCurrentUrl());
	//driver.close();


}

