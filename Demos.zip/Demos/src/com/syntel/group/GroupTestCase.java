package com.syntel.group;
import org.testng.Assert;
import org.testng.annotations.Test;
public class GroupTestCase {
	@Test(groups="sanity")
	  public void f1() {
	  System.out.println("sanity::f1");
	 Assert.fail();
	  }
	  @Test(groups="sanity")
	  public void f3() {
	  System.out.println("sanity::f3");
	  
	  }
	  @Test(groups="sanity")
	  public void f5() {
	  System.out.println("sanity::f5");
	  }
	  
//	  @Test(groups="regression")
//	  public void f2() {
//	  System.out.println("regression::f2");
//	  }
//	  @Test(groups="regression")
//	  public void f4() {
//	  System.out.println("regression::f4");
//	  }
//	  @Test(groups="regression")
//	  public void f6() {
//	  System.out.println("regression::f6");
//	  }	  
	  @Test(groups="regression",dependsOnGroups={"sanity"})
	  public void f2() {
	  System.out.println("regression::f2");
	  }
	  @Test(groups="regression",dependsOnGroups={"sanity"})
	  public void f4() {
	  System.out.println("regression::f4");
	  }
	  @Test(groups="regression",dependsOnGroups={"sanity"})
	  public void f6() {
	  System.out.println("regression::f6");
	  }
}
