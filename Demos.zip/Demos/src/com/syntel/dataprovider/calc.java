package com.syntel.dataprovider;
public class calc {
public static int add(int a,int b)
{
	return a+b;
}
}
