package com.syntel.dataprovider;

import org.junit.BeforeClass;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class dataProviderDemo {
//calc c=null;
//@BeforeClass
//public void init()
//{
//	c=new calc();
//}

@Test(dataProvider="dpAdd")
public void test_add(int a,int b,int exp_res)
{
//	Assert.assertEquals(calc.add(a,b),exp_res,"Actual result not equal to Expected result");
	int actual_result= calc.add(a,b);
	if (actual_result==exp_res){
		System.out.println("test passed");
	}
	else {
		System.out.println("test failed");
		Assert.fail("Actual result not equal to Expected result");
	}
}

@DataProvider(name="dpAdd")
public Object[][]getData()
{
	Object table[][]={
			{10,10,20},
			{20,20,30},
			{20,20,40},
			{5,5,20}
	};
	return table;
}
}
