package com.syntel.excelDP;

import java.io.*;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class excel1 {
	static File exl ;
	static Workbook wbk = null;
	static Sheet sht1 = null;
	static Object[][]data=null;
	static{
		System.out.println("inside static ");
		try{
		exl= new File("D:\\ManishaTesting\\Testing\\AddParameters.xls");
			wbk =Workbook.getWorkbook(exl);
			sht1=wbk.getSheet("testdata");
		}
		catch(BiffException be){System.out.println("be"+be);}
		catch(IOException ie){System.out.println("ie"+ie);}
		catch(Exception e)
		{			System.out.println("exe"+e);}
	}
	public static Object[][]readDataFromExcel()
	{
		System.out.println("insdie read");
		int row_count= sht1.getRows();//5
		int col_count= sht1.getColumns();//3
		data =new Object[row_count-1][col_count];//[4][3]
		//System.out.println("rows "+ row_count);
		//System.out.println("column "+ col_count);
		for (int row=1; row<row_count;row++){
			for(int col=0;col<col_count;col++){
			//System.out.print(sht1.getCell(col, row).getContents()+" ");
				data[row-1][col]=sht1.getCell(col, row).getContents();
			}
			//System.out.println();
		}
		wbk.close();
		return data;
		}
	public static void main(String[]ar)
	{
		//readDataFromExcel();
	}
}
