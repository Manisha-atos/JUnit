package com.syntel.excelDP;

import org.testng.Assert;
//import org.junit.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ExcelTestCase {
	calculator calc = null;
	
	@BeforeClass
	  public void create_calc_instance(){		 
	calc = new calculator();	  
	}
	
	@DataProvider(name="dp_add")
	
	public Object[][]getData(){		
			
	return excel1.readDataFromExcel();
		
	}
	@Test(dataProvider= "dp_add")
	public void testAdd(String a, String b, String Expected_result) {
		int n1=Integer.parseInt(a);
		int n2=Integer.parseInt(b);
		int exp=Integer.parseInt(Expected_result);
		Assert.assertEquals(calc.add(n1,n2), exp);
//		Assert.assertEquals("Actual result not matching with expected", exp,calc.add(n1,n2));

  }
	@AfterClass
	
	public void release_calc_instance(){
			
	calc = null;
		}
	}


