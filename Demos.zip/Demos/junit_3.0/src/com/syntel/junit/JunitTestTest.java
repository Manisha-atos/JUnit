package com.syntel.junit;

import junit.framework.TestCase;

public class JunitTestTest extends TestCase {

	JunitTest t;
	
	
	protected void setUp() throws Exception {
t=new JunitTest();
System.out.println("In JunitTest setup.......");

	}

	protected void tearDown() throws Exception {
		t=null;
		System.out.println("In JunitTest tearDown.......");
	}

	public void testAcceptLoginId() {
		fail("Not yet implemented");
	}
	
	

	public void testAcceptLocation() {
		fail("Not yet implemented");
	}

}
