package com.syntel.junit;

import junit.framework.TestCase;

public class TestDemoTest extends TestCase {
TestDemo t;

@Override
	protected void setUp() throws Exception {
t=new TestDemo();
System.out.println("In set UP......");
}
	
@Override
	protected void tearDown() throws Exception {
   t=null;	
System.out.println("In tearDown.....");   
}	


public void testAcceptAgeWith20() {
	assertEquals(true,t.acceptAge(20));
	}
public void testAcceptAgeWith60() {
	assertEquals(true,t.acceptAge(60));
	}

public void testAcceptAgeWith25() {
	assertEquals(true,t.acceptAge(25));
	}

public void testAcceptAgeWith19() {
	assertEquals(false,t.acceptAge(19));
	}
public void testAcceptAgeWith61() {
	assertEquals(false,t.acceptAge(61));
	}


public void AcceptMobile() {
	
}

}
