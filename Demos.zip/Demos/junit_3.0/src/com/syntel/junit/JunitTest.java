package com.syntel.junit;

public class JunitTest {

	public boolean acceptLoginId(String loginId){
		return loginId.matches("[A-z][A-z][1-9][0-9]{3,6}");
	}

	public boolean acceptLocation(String location){
		return location.matches("[MUMBAI]|[PUNE][CHENNAI]");
	}
}
