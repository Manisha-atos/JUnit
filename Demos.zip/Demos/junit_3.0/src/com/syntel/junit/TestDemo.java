package com.syntel.junit;

public class TestDemo {

	public boolean acceptAge(int age){
		return age>=20 && age<=60;
	}
	

	public boolean acceptMobile(String mobile){
		return mobile.matches("[1-9][0-9]{9,9}");
	}
	
}
